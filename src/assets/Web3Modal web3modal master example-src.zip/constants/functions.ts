export const FUNCTION_BALANCE_OF = "balanceOf";
export const FUNCTION_TRANSFER = "transfer";
